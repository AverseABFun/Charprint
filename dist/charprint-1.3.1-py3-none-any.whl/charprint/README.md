# Charprint!
---
Replace all that unnessasary "import sys" and "for i in string" with "from charprint import charprint" and "charprint(string, 'red' cursorused=False)"!
> NOTE: There is now the "blanket()" function!
NOTE: There is now the "charinput()" function!