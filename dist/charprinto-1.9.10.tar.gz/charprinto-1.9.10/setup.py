# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['charprinto', 'charprinto.charprinto', 'charprinto.tests']

package_data = \
{'': ['*']}

install_requires = \
['cursor>=1.3.4,<2.0.0', 'termcolor>=1.1.0,<2.0.0']

setup_kwargs = {
    'name': 'charprinto',
    'version': '1.9.10',
    'description': '',
    'long_description': None,
    'author': 'AverseABFun',
    'author_email': 'averse.abfun@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
