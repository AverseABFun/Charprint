# Charprinto!
---
Replace all that unnessasary "`import sys`" and "`for i in string`" with "`from charprinto import charprint`" and "`charprint("I love charprinto!", 'red' cursorused=False, end="")`"!

> NOTE: There is now the "blanket()" function!
NOTE: There is now the "charinput()" function!
Contact me at <averse.abfun@gmail.com>